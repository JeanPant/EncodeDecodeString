﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using K2BlankService;
using K2Service;

//SourceCode References
using SourceCode.SmartObjects.Services.ServiceSDK;
using SourceCode.SmartObjects.Services.ServiceSDK.Objects;
using SourceCode.SmartObjects.Services.ServiceSDK.Types;


namespace K2BlankService
{
    class K2BlankService : ServiceAssemblyBase
    {
        private const string _ServiceInstanceConfig1 = "";      //No default Value
        private const string _ServiceInstanceConfig2 = "50";    //Yes default value

        //Define the ServiceInstance Properties
        public override string GetConfigSection()
        {
            base.Service.ServiceConfiguration.Add("ServiceInstance Config #1", _ServiceInstanceConfig1);
            base.Service.ServiceConfiguration.Add("ServiceInstance Config #2", _ServiceInstanceConfig2);

            return base.GetConfigSection();
        }

        //Define the properties of the ServiceInstance based on the values from the Resource File
        public override string DescribeSchema()
        {
            string strServiceInstanceConfig1 = string.Empty;
            string strServiceInstanceConfig2 = string.Empty;

            base.Service.Name = Resources.K2_Service_Name;
            base.Service.MetaData.DisplayName = Resources.K2_Service_DisplayName;
            base.Service.MetaData.Description = Resources.K2_Service_Description;

            strServiceInstanceConfig1 = base.Service.ServiceConfiguration["ServiceInstance Config #1"] + string.Empty;
            strServiceInstanceConfig2 = base.Service.ServiceConfiguration["ServiceInstance Config #2"] + string.Empty;

            return base.DescribeSchema();
        }

        public override void Extend()
        {
            throw new NotImplementedException();
        }

        //Set the Properties of the ServiceInstance based on the values entered.

        public override void Execute()
        {
            string strServiceInstanceConfig1 = string.Empty;
            string strServiceInstanceConfig2 = string.Empty;

            Dictionary<string, object> dicProperties = new Dictionary<string, object>();
            Dictionary<string, object> dicParameters = new Dictionary<string, object>();

            ListMethod list = null;

            base.ServicePackage.ResultTable = null;

            try
            {
                strServiceInstanceConfig1 = base.Service.ServiceConfiguration["ServiceInstance Config #1"] + string.Empty;
                strServiceInstanceConfig2 = base.Service.ServiceConfiguration["ServiceInstance Config #2"] + string.Empty;

                foreach (ServiceObject serviceObject in base.Service.ServiceObjects)
                {
                    foreach (Method method in serviceObject.Methods)
                    {
                        foreach (Property property in serviceObject.Properties)
                        {
                            if ((property.Value != null) && (!string.IsNullOrEmpty(property.Value + string.Empty)))
                            {
                                dicProperties.Add(property.Name, property.Value);
                            }
                        }
                        foreach (MethodParameter methodParameter in method.MethodParameters)
                        {
                            if ((methodParameter.Value != null) && (!string.IsNullOrEmpty(methodParameter.Value + string.Empty)))
                            {
                                dicParameters.Add(methodParameter.Name, methodParameter.Value);
                            }
                        }

                        if (serviceObject.Name.Equals(Resources.K2_Search_ServiceObject_Name))
                        {
                            list = new ListMethod(strServiceInstanceConfig1, strServiceInstanceConfig2);

                            if (method.Name.Equals(Resources.K2_Search_List_Method_Name))
                            {
                                base.ServicePackage.ResultTable = list.List(dicProperties, dicParameters);
                            }
                            
                        }
                    }
                }
                base.ServicePackage.IsSuccessful = true;
            }
            catch (Exception exp)
            {
                base.ServicePackage.IsSuccessful = false;
                base.ServicePackage.ServiceMessages.Add(new ServiceMessage(exp.Message, MessageSeverity.Error));

                throw new Exception("Error Execute: " + exp.Message);
            }
        }
    }
}
