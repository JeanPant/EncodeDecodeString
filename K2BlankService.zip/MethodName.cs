﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using K2Service;

//SourceCode References
using SourceCode.SmartObjects.Services.ServiceSDK.Objects;
using SourceCode.SmartObjects.Services.ServiceSDK.Types;

namespace K2Service
{
    class ListMethod : IDisposable
    {
        //Local Variables to match ServiceInstance Configurations
        private string _ServiceInstanceConfig1 = string.Empty;
        private string _ServiceInstanceConfig2 = string.Empty;

        internal ListMethod()
        {

        }

        internal ListMethod(string strServiceInstanceConfig1, string strServiceInstanceConfig2)
        {
            _ServiceInstanceConfig1 = strServiceInstanceConfig1;
            _ServiceInstanceConfig2 = strServiceInstanceConfig2;
        }

        public void Dispose()
        {
            _ServiceInstanceConfig1 = string.Empty;
            _ServiceInstanceConfig2 = string.Empty;
        }

        //Set properties of the ServiceObject based on the values from the Resource File
        internal ServiceObject DescribeServiceObject()
        {
            ServiceObject serviceObject = null;

            serviceObject = new ServiceObject();
            serviceObject.Name = Resources.K2_Search_ServiceObject_Name;
            serviceObject.MetaData.DisplayName = Resources.K2_Search_ServiceObject_DisplayName;
            serviceObject.MetaData.Description = Resources.K2_Search_ServiceObject_Description;
            serviceObject.Type = typeof(ListMethod).Name;
            serviceObject.Active = true;
            serviceObject.Properties = GetProperties(serviceObject);
            serviceObject.Methods = GetMethods(serviceObject);

            return serviceObject;
        }

        //Define the SmartObjects Properties and the Property Types
        private Properties GetProperties(ServiceObject serviceObject)
        {
            Properties properties = new Properties();

            properties.Create(new Property("InputProperty1", "System.String", SoType.Text, new MetaData("InputProperty1", string.Empty)));
            properties.Create(new Property("ReturnProperty1", "System.String", SoType.Text, new MetaData("ReturnProperty1", string.Empty)));
            properties.Create(new Property("ReturnProperty2", "System.String", SoType.Text, new MetaData("ReturnProperty2", string.Empty)));
            properties.Create(new Property("ReturnProperty3", "System.String", SoType.Text, new MetaData("ReturnProperty3", string.Empty)));
            properties.Create(new Property("ReturnProperty4", "System.String", SoType.Text, new MetaData("ReturnProperty4", string.Empty)));
            properties.Create(new Property("ReturnProperty4", "System.String", SoType.Text, new MetaData("ReturnProperty5", string.Empty)));

            return properties;
        }

        //Define the method with all its properties based on the values from the Resource File 
        private Methods GetMethods(ServiceObject serviceObject)
        {
            Methods methods = new Methods();

            methods.Create(new Method(Resources.K2_Search_List_Method_Name, MethodType.List, new MetaData(Resources.K2_Search_List_Method_DisplayName, 
                   Resources.K2_Search_List_Method_Description), 
                   GetRequiredProperties(serviceObject, Resources.K2_Search_List_Method_Name), 
                   GetMethodParameters(serviceObject, Resources.K2_Search_List_Method_Name), 
                   GetInputProperties(serviceObject, Resources.K2_Search_List_Method_Name), 
                   GetReturnProperties(serviceObject, Resources.K2_Search_List_Method_Name)));

            return methods;
        }

        //Define the Input Properties of the SmartObject Method
        private InputProperties GetInputProperties(ServiceObject serviceObject, string strMethodName)
        {
            InputProperties inputProperties = new InputProperties();

            if (strMethodName.Equals(Resources.K2_Search_List_Method_Name))
            {
                inputProperties.Add(serviceObject.Properties["InputProperty1"]);
            }

            return inputProperties;
        }

        //Define the Method Parameters of the SmartObject Method
        private MethodParameters GetMethodParameters(ServiceObject serviceObject, string strMethodName)
        {
            MethodParameters methodParameters = new MethodParameters();

            return methodParameters;
        }

        //Set the Input Properties of the SmartObject Method

        private Validation GetRequiredProperties(ServiceObject serviceObject, string strMethodName)
        {
            Validation validation = new Validation();
            RequiredProperties requiredProperties = new RequiredProperties();

            if (strMethodName.Equals(Resources.K2_Search_List_Method_Name))
            {
                requiredProperties.Add(serviceObject.Properties["InputProperty1"]);
            }

            validation.RequiredProperties = requiredProperties;

            return validation;
        }

        //Define the Return Properties of the SmartObject Method
        private ReturnProperties GetReturnProperties(ServiceObject serviceObject, string strMethodName)
        {
            ReturnProperties returnProperties = new ReturnProperties();

            if (strMethodName.Equals(Resources.K2_Search_List_Method_Name))
            {
                returnProperties.Add(serviceObject.Properties["ReturnProperty1"]);
                returnProperties.Add(serviceObject.Properties["ReturnProperty2"]);
                returnProperties.Add(serviceObject.Properties["ReturnProperty3"]);
                returnProperties.Add(serviceObject.Properties["ReturnProperty4"]);
                returnProperties.Add(serviceObject.Properties["ReturnProperty5"]);
            }


            return returnProperties;
        }

        //The method that will execute the List and return a DataTable of results
        internal DataTable List(Dictionary<string, object> dicProperties, Dictionary<string, object> dicParameters)
        {
            DataTable dataTable = null;

            try
            {
                
            }
            catch (Exception ex)
            {
                throw new Exception ("Error List: " + ex.ToString());
            }

            return dataTable;
        }

        //Define the DataTable with its Properties
        private DataTable GetDataTable()
        {
            DataTable dataTable = new DataTable();

            dataTable.Columns.Add(new DataColumn("ReturnProperty1", typeof(String)));
            dataTable.Columns.Add(new DataColumn("ReturnProperty2", typeof(String)));
            dataTable.Columns.Add(new DataColumn("ReturnProperty3", typeof(String)));
            dataTable.Columns.Add(new DataColumn("ReturnProperty4", typeof(String)));
            dataTable.Columns.Add(new DataColumn("ReturnProperty5", typeof(String)));

            return dataTable;
        }
    }
}
